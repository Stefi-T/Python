from graphics.Dgraphics.cuboid import cuboid
from graphics.Dgraphics.sphere import sphere
