def rectangle(x,y):
    a=x*y
    p=2*(x+y)
    print("Perimeter of rectangle:",p)
    print("Area of rectangle:",a)
l=int(input("Enter length of rectangle:"))
b=int(input("Enter breadth of rectangle:"))
rectangle(l,b)
