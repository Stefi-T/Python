from graphics import *
from graphics.Dgraphics import cuboid,sphere
from graphics import rectangle,circle
graphics.rectangle.rectangle()
graphics.circle.circle()
graphics.Dgraphics.cuboid.cuboid()
graphics.Dgraphics.sphere.sphere()
